</main>


    <!----------------------------------
    footer
    ----------------------------------->
    <footer class="l-footer">
        <div class="l-footer-inner--copy c-text--12 c-textcolor--white"><span>&copy;System Support Inc.</span></div>
        <!-- sp cta position -->
        <div class="l-footer-inner--ctaposition pc--none"></div>
    </footer>
    <!-- script -->
    <!-- <script src="./assets/js/script.js"></script> -->
    <?php wp_footer(); ?>
</body>
</html>